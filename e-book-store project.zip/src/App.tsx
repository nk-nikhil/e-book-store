import React, { useState } from 'react';
import { Routes, Route } from 'react-router-dom';
import { CartProvider } from './context/CartContext';
import Header from './components/Header/Header';
import Sidebar from './components/Sidebar/Sidebar';
import HomePage from './pages/HomePage/HomePage';
import CataloguePage from './pages/CataloguePage/CataloguePage';
import BookDetailPage from './pages/BookDetailPage/BookDetailPage';
import CheckoutPage from './pages/CheckoutPage/CheckoutPage';
import PaymentPage from './pages/PaymentPage/PaymentPage';
import PaymentConfirmPage from './pages/PaymentConfirmPage/PaymentConfirmPage';
import PlaceholderPage from './pages/PlaceholderPage/PlaceholderPage';
import styles from './App.module.css';

const App: React.FC = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('all');

  const handleMenuToggle = () => setSidebarOpen(prev => !prev);
  const handleSelectCategory = (id: string) => setSelectedCategory(id);

  return (
    <CartProvider>
      <div className={styles.appShell}>
        <Header onMenuToggle={handleMenuToggle} />
        <Sidebar
          isOpen={sidebarOpen}
          selectedCategory={selectedCategory}
          onSelectCategory={handleSelectCategory}
        />
        <div className={`${styles.content} ${sidebarOpen ? styles.contentShifted : ''}`}>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/catalogue" element={<CataloguePage />} />
            <Route path="/book/:id" element={<BookDetailPage />} />
            <Route path="/checkout" element={<CheckoutPage />} />
            <Route path="/payment" element={<PaymentPage />} />
            <Route path="/payment/confirm" element={<PaymentConfirmPage />} />
            <Route path="/orders" element={<PlaceholderPage title="My Orders" description="Track and manage your book orders here." />} />
            <Route path="/wishlist" element={<PlaceholderPage title="My Wishlist" description="Books you've saved for later." />} />
            <Route path="/profile" element={<PlaceholderPage title="My Profile" description="Manage your account and preferences." />} />
            <Route path="*" element={<PlaceholderPage title="404 — Page Not Found" description="The page you're looking for doesn't exist." />} />
          </Routes>
        </div>
      </div>
    </CartProvider>
  );
};

export default App;
