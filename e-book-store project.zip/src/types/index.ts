export interface Review {
  id: number;
  reviewer: string;
  rating: number;
  comment: string;
  date: string;
}

export interface Author {
  name: string;
  bio: string;
  avatarColor: string;
}

export interface Book {
  id: number;
  title: string;
  author: string;
  authorDetail?: Author;
  price: number;
  originalPrice?: number;
  coverColor: string;
  coverTextColor?: string;
  deliveryDate?: string;
  rating?: number;
  category: string;
  tag?: string;
  description?: string;
  publisher?: string;
  language?: string;
  pages?: number;
  soldCount?: number;
  reviews?: Review[];
}

export interface Category {
  id: string;
  label: string;
}

export type SectionKey = 'recommended' | 'bestsellers' | 'new-launches';

export interface CartItem {
  book: Book;
  quantity: number;
}
