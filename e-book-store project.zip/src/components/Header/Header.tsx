import React, { useState } from 'react';
import styles from './Header.module.css';
import { Link, NavLink } from 'react-router-dom';
import { useCart } from '../../context/CartContext';

interface HeaderProps {
  onMenuToggle: () => void;
}

const Header: React.FC<HeaderProps> = ({ onMenuToggle }) => {
  const [searchValue, setSearchValue] = useState('');
  const { totalCount } = useCart();

  return (
    <header className={styles.header}>
      <div className={styles.left}>
        <button className={styles.menuBtn} onClick={onMenuToggle} aria-label="Toggle sidebar">
          <span />
          <span />
          <span />
        </button>
        <Link to="/" className={styles.brand}>
          <span className={styles.brandIcon}>📚</span>
          <span className={styles.brandName}>Book Store</span>
        </Link>
      </div>

      <nav className={styles.nav}>
        <NavLink to="/" end className={({ isActive }) => isActive ? `${styles.navLink} ${styles.navActive}` : styles.navLink}>
          Home
        </NavLink>
        <NavLink to="/catalogue" className={({ isActive }) => isActive ? `${styles.navLink} ${styles.navActive}` : styles.navLink}>
          Catalogue
        </NavLink>
        <NavLink to="/orders" className={({ isActive }) => isActive ? `${styles.navLink} ${styles.navActive}` : styles.navLink}>
          My Orders
        </NavLink>
        <NavLink to="/wishlist" className={({ isActive }) => isActive ? `${styles.navLink} ${styles.navActive}` : styles.navLink}>
          My Wishlist
        </NavLink>
        <NavLink to="/profile" className={({ isActive }) => isActive ? `${styles.navLink} ${styles.navActive}` : styles.navLink}>
          My Profile
        </NavLink>
      </nav>

      <div className={styles.center}>
        <div className={styles.searchBar}>
          <span className={styles.searchIcon}>🔍</span>
          <input
            type="text"
            placeholder="What do you want to read today?"
            value={searchValue}
            onChange={e => setSearchValue(e.target.value)}
            className={styles.searchInput}
          />
        </div>
      </div>

      <div className={styles.right}>
        <div className={styles.filterGroup}>
          <select className={styles.select} aria-label="Language">
            <option>Language</option>
            <option>English</option>
            <option>Hindi</option>
          </select>
          <select className={styles.select} aria-label="Sort">
            <option>Newest Releases above all</option>
            <option>Price: Low to High</option>
            <option>Price: High to Low</option>
          </select>
          <select className={styles.select} aria-label="Price Range">
            <option>Price Range</option>
            <option>Under ₹200</option>
            <option>₹200 – ₹500</option>
            <option>Above ₹500</option>
          </select>
          <select className={styles.select} aria-label="Sortby">
            <option>Sortby</option>
            <option>Rating</option>
            <option>Popularity</option>
          </select>
        </div>
        <Link to="/checkout" className={styles.cartBtn} aria-label="Go to Cart">
          🛒
          {totalCount > 0 && (
            <span className={styles.cartBadge}>{totalCount}</span>
          )}
        </Link>
      </div>
    </header>
  );
};

export default Header;
