import React from 'react';
import BookCard from '../BookCard/BookCard';
import { Book } from '../../types';
import styles from './BookSection.module.css';

interface BookSectionProps {
  title: string;
  books: Book[];
  onAddToCart: (book: Book) => void;
}

const BookSection: React.FC<BookSectionProps> = ({ title, books, onAddToCart }) => {
  return (
    <section className={styles.section}>
      <h2 className={styles.title}>{title}</h2>
      <div className={styles.scrollRow}>
        {books.map(book => (
          <BookCard key={book.id} book={book} onAddToCart={onAddToCart} />
        ))}
      </div>
    </section>
  );
};

export default BookSection;
