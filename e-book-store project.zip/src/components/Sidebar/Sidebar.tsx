import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { categories } from '../../data/books';
import styles from './Sidebar.module.css';

interface SidebarProps {
  isOpen: boolean;
  selectedCategory: string;
  onSelectCategory: (id: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, selectedCategory, onSelectCategory }) => {
  const navigate = useNavigate();

  const handleCategoryClick = (id: string) => {
    onSelectCategory(id);
    // Navigate to catalogue filtered by the chosen category
    navigate(id === 'all' ? '/catalogue' : `/catalogue?category=${id}`);
  };

  return (
    <aside className={`${styles.sidebar} ${isOpen ? styles.open : ''}`}>
      {/* Page navigation links */}
      <nav>
        <ul className={styles.linkList}>
          <li>
            <NavLink to="/" end className={({ isActive }) => isActive ? styles.activeLink : styles.link}>
              🏠 Home
            </NavLink>
          </li>
          <li>
            <NavLink to="/catalogue" className={({ isActive }) => isActive ? styles.activeLink : styles.link}>
              📚 Catalogue
            </NavLink>
          </li>
          <li>
            <NavLink to="/orders" className={({ isActive }) => isActive ? styles.activeLink : styles.link}>
              📦 My Orders
            </NavLink>
          </li>
          <li>
            <NavLink to="/wishlist" className={({ isActive }) => isActive ? styles.activeLink : styles.link}>
              ❤️ Wishlist
            </NavLink>
          </li>
          <li>
            <NavLink to="/profile" className={({ isActive }) => isActive ? styles.activeLink : styles.link}>
              👤 Profile
            </NavLink>
          </li>
        </ul>
      </nav>

      <div className={styles.divider} />

      {/* Category filter — navigates to /catalogue?category=xxx */}
      <p className={styles.sectionLabel}>Browse by Category</p>
      <nav>
        <ul className={styles.categoryList}>
          {categories.map(cat => (
            <li key={cat.id}>
              <button
                className={`${styles.categoryItem} ${selectedCategory === cat.id ? styles.active : ''}`}
                onClick={() => handleCategoryClick(cat.id)}
              >
                {cat.label}
              </button>
            </li>
          ))}
        </ul>
      </nav>
    </aside>
  );
};

export default Sidebar;
