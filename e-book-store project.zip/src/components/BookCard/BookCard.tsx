import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Book } from '../../types';
import { useCart } from '../../context/CartContext';
import styles from './BookCard.module.css';

interface BookCardProps {
  book: Book;
  onAddToCart?: (book: Book) => void;
}

const BookCard: React.FC<BookCardProps> = ({ book, onAddToCart }) => {
  const navigate = useNavigate();
  const { addToCart } = useCart();

  const handleAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(book);
    onAddToCart?.(book);
  };

  return (
    <div className={styles.card} onClick={() => navigate(`/book/${book.id}`)}>
      {book.tag && <span className={styles.tag}>{book.tag}</span>}

      {/* Book Cover */}
      <div
        className={styles.cover}
        style={{ backgroundColor: book.coverColor }}
      >
        <span
          className={styles.coverTitle}
          style={{ color: book.coverTextColor ?? '#fff' }}
        >
          {book.title}
        </span>
      </div>

      {/* Info */}
      <div className={styles.info}>
        <p className={styles.title}>{book.title}</p>
        <p className={styles.author}>{book.author}</p>
        {book.deliveryDate && (
          <p className={styles.delivery}>Delivery by {book.deliveryDate}</p>
        )}
        <div className={styles.priceRow}>
          <span className={styles.price}>₹{book.price}</span>
          {book.originalPrice && (
            <span className={styles.originalPrice}>₹{book.originalPrice}</span>
          )}
        </div>
        <button
          className={styles.addBtn}
          onClick={handleAdd}
          aria-label={`Add ${book.title} to cart`}
        >
          Add to Cart
        </button>
      </div>
    </div>
  );
};

export default BookCard;
