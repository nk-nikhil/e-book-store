import React from 'react';
import styles from './PlaceholderPage.module.css';

interface PlaceholderPageProps {
  title: string;
  description?: string;
}

const PlaceholderPage: React.FC<PlaceholderPageProps> = ({ title, description }) => (
  <main className={styles.page}>
    <h1 className={styles.title}>{title}</h1>
    <p className={styles.desc}>{description ?? 'This section is coming soon.'}</p>
  </main>
);

export default PlaceholderPage;
