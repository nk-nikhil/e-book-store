import React, { useState, useMemo, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { allBooks, categories, brands } from '../../data/books';
import { useCart } from '../../context/CartContext';
import { Book } from '../../types';
import styles from './CataloguePage.module.css';

const StarRating: React.FC<{ rating: number; size?: number }> = ({ rating, size = 12 }) => {
  return (
    <span className={styles.stars} style={{ fontSize: size }}>
      {[1, 2, 3, 4, 5].map(i => (
        <span key={i} style={{ color: i <= Math.round(rating) ? '#f39c12' : '#4a5568' }}>★</span>
      ))}
    </span>
  );
};

const CataloguePage: React.FC = () => {
  const navigate = useNavigate();
  const { addToCart } = useCart();

  const [searchParams] = useSearchParams();
  const [selectedCategory, setSelectedCategory] = useState(
    searchParams.get('category') ?? 'all'
  );

  // Sync category when URL search param changes (e.g. sidebar click)
  useEffect(() => {
    const cat = searchParams.get('category') ?? 'all';
    setSelectedCategory(cat);
  }, [searchParams]);
  const [selectedBrand, setSelectedBrand] = useState('All Brands');
  const [searchQuery, setSearchQuery] = useState('');
  const [priceRange, setPriceRange] = useState('all');
  const [sortBy, setSortBy] = useState('default');
  const [toast, setToast] = useState<string | null>(null);

  const handleAddToCart = (e: React.MouseEvent, book: Book) => {
    e.stopPropagation();
    addToCart(book);
    setToast(`"${book.title}" added to cart!`);
    setTimeout(() => setToast(null), 2500);
  };

  const filtered = useMemo(() => {
    let list = [...allBooks];

    if (selectedCategory !== 'all') {
      list = list.filter(b => b.category === selectedCategory);
    }

    if (selectedBrand !== 'All Brands') {
      list = list.filter(b => b.publisher === selectedBrand);
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter(b =>
        b.title.toLowerCase().includes(q) || b.author.toLowerCase().includes(q)
      );
    }

    if (priceRange === 'under200') list = list.filter(b => b.price < 200);
    else if (priceRange === '200-500') list = list.filter(b => b.price >= 200 && b.price <= 500);
    else if (priceRange === 'above500') list = list.filter(b => b.price > 500);

    if (sortBy === 'price-asc') list.sort((a, b) => a.price - b.price);
    else if (sortBy === 'price-desc') list.sort((a, b) => b.price - a.price);
    else if (sortBy === 'rating') list.sort((a, b) => (b.rating ?? 0) - (a.rating ?? 0));
    else if (sortBy === 'popular') list.sort((a, b) => (b.soldCount ?? 0) - (a.soldCount ?? 0));

    return list;
  }, [selectedCategory, selectedBrand, searchQuery, priceRange, sortBy]);

  return (
    <main className={styles.page}>
      {toast && <div className={styles.toast}>{toast}</div>}

      {/* Top toolbar */}
      <div className={styles.toolbar}>
        <div className={styles.searchBar}>
          <span className={styles.searchIcon}>🔍</span>
          <input
            type="text"
            placeholder="Search by title or author..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className={styles.searchInput}
          />
          {searchQuery && (
            <button className={styles.clearBtn} onClick={() => setSearchQuery('')}>✕</button>
          )}
        </div>

        <div className={styles.filters}>
          <select
            className={styles.select}
            value={priceRange}
            onChange={e => setPriceRange(e.target.value)}
            aria-label="Price range"
          >
            <option value="all">All Prices</option>
            <option value="under200">Under ₹200</option>
            <option value="200-500">₹200 – ₹500</option>
            <option value="above500">Above ₹500</option>
          </select>

          <select
            className={styles.select}
            value={sortBy}
            onChange={e => setSortBy(e.target.value)}
            aria-label="Sort by"
          >
            <option value="default">Sort: Default</option>
            <option value="price-asc">Price: Low to High</option>
            <option value="price-desc">Price: High to Low</option>
            <option value="rating">Top Rated</option>
            <option value="popular">Most Popular</option>
          </select>
        </div>
      </div>

      {/* Brand filter strip */}
      <div className={styles.brandStrip}>
        {brands.map(brand => (
          <button
            key={brand}
            className={`${styles.brandBtn} ${selectedBrand === brand ? styles.brandActive : ''}`}
            onClick={() => setSelectedBrand(brand)}
          >
            {brand}
          </button>
        ))}
      </div>

      {/* Category pills */}
      <div className={styles.categoryStrip}>
        {categories.map(cat => (
          <button
            key={cat.id}
            className={`${styles.catPill} ${selectedCategory === cat.id ? styles.catActive : ''}`}
            onClick={() => setSelectedCategory(cat.id)}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Results count */}
      <p className={styles.resultCount}>
        {filtered.length} book{filtered.length !== 1 ? 's' : ''} found
        {selectedCategory !== 'all' && ` in "${categories.find(c => c.id === selectedCategory)?.label}"`}
      </p>

      {/* Book grid */}
      {filtered.length > 0 ? (
        <div className={styles.grid}>
          {filtered.map(book => (
            <div
              key={book.id}
              className={styles.card}
              onClick={() => navigate(`/book/${book.id}`)}
            >
              {book.tag && <span className={styles.tag}>{book.tag}</span>}

              <div className={styles.cover} style={{ backgroundColor: book.coverColor }}>
                <span className={styles.coverTitle} style={{ color: book.coverTextColor ?? '#fff' }}>
                  {book.title}
                </span>
                <span className={styles.coverAuthor} style={{ color: book.coverTextColor ?? '#fff' }}>
                  {book.author}
                </span>
              </div>

              <div className={styles.info}>
                <p className={styles.title}>{book.title}</p>
                <p className={styles.author}>by <span>{book.author}</span></p>
                {book.rating && <StarRating rating={book.rating} />}
                {book.deliveryDate && (
                  <p className={styles.delivery}>Delivery by {book.deliveryDate}</p>
                )}
                <div className={styles.priceRow}>
                  <span className={styles.price}>₹{book.price}</span>
                  {book.originalPrice && (
                    <span className={styles.original}>₹{book.originalPrice}</span>
                  )}
                </div>
                <button
                  className={styles.addBtn}
                  onClick={e => handleAddToCart(e, book)}
                >
                  Add to Cart
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className={styles.empty}>
          <p>No books found matching your filters.</p>
          <button className={styles.resetBtn} onClick={() => {
            setSelectedCategory('all');
            setSelectedBrand('All Brands');
            setSearchQuery('');
            setPriceRange('all');
            setSortBy('default');
          }}>
            Reset Filters
          </button>
        </div>
      )}
    </main>
  );
};

export default CataloguePage;
