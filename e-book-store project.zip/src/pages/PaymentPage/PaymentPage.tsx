import React, { useState } from 'react';
import { useNavigate, useSearchParams, useLocation } from 'react-router-dom';
import { useCart } from '../../context/CartContext';
import { Book } from '../../types';
import styles from './PaymentPage.module.css';

type PayTab = 'credit' | 'debit' | 'upi' | 'wallet';

/** Format card number as XXXX-XXXX-XXXX-XXXX */
const formatCard = (v: string) =>
  v.replace(/\D/g, '').slice(0, 16).replace(/(.{4})/g, '$1-').replace(/-$/, '');

/** Format expiry as MM/YY */
const formatExpiry = (v: string) => {
  const clean = v.replace(/\D/g, '').slice(0, 4);
  if (clean.length > 2) return `${clean.slice(0, 2)}/${clean.slice(2)}`;
  return clean;
};

const PaymentPage: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { clearCart } = useCart();

  const locationState = useLocation().state as { purchased?: Book[] } | null;
  const purchased = locationState?.purchased ?? [];
  const amount = searchParams.get('amount') ?? '0';

  const [tab, setTab] = useState<PayTab>('credit');
  const [cardNumber, setCardNumber] = useState('');
  const [nameOnCard, setNameOnCard] = useState('');
  const [cvv, setCvv] = useState('');
  const [expiry, setExpiry] = useState('');
  const [upiId, setUpiId] = useState('');
  const [wallet, setWallet] = useState('Paytm');
  const [error, setError] = useState('');
  const [processing, setProcessing] = useState(false);

  const validate = () => {
    if (tab === 'credit' || tab === 'debit') {
      if (cardNumber.replace(/-/g, '').length < 16) return 'Enter a valid 16-digit card number.';
      if (!nameOnCard.trim()) return 'Enter the name on card.';
      if (cvv.length < 3) return 'Enter a valid CVV.';
      if (expiry.length < 5) return 'Enter a valid expiry date.';
    }
    if (tab === 'upi') {
      if (!upiId.includes('@')) return 'Enter a valid UPI ID (e.g. name@upi).';
    }
    return '';
  };

  const handlePay = () => {
    const err = validate();
    if (err) { setError(err); return; }
    setError('');
    setProcessing(true);
    // Simulate payment processing delay
    setTimeout(() => {
      clearCart();
      navigate('/payment/confirm', { state: { purchased } });
    }, 1400);
  };

  const tabs: { id: PayTab; label: string; icon: string }[] = [
    { id: 'credit', label: 'Credit Card', icon: '💳' },
    { id: 'debit',  label: 'Debit Card',  icon: '🏧' },
    { id: 'upi',    label: 'UPI',          icon: '📱' },
    { id: 'wallet', label: 'Wallet',       icon: '👛' },
  ];

  return (
    <div className={styles.scene}>
      {/* ── Illustrated background: floating book shapes ── */}
      <div className={styles.bg}>
        {/* large open book — bottom right */}
        <svg className={`${styles.deco} ${styles.decoBottomRight}`} viewBox="0 0 260 180" fill="none">
          <path d="M10 160 Q130 100 250 160 L250 20 Q130 80 10 20Z" fill="#c8762a" opacity=".85"/>
          <path d="M130 100 L130 160" stroke="#a05a1a" strokeWidth="3"/>
          <rect x="30" y="40" width="80" height="8" rx="2" fill="#a05a1a" opacity=".4"/>
          <rect x="30" y="56" width="60" height="6" rx="2" fill="#a05a1a" opacity=".3"/>
          <rect x="150" y="40" width="80" height="8" rx="2" fill="#a05a1a" opacity=".4"/>
          <rect x="150" y="56" width="60" height="6" rx="2" fill="#a05a1a" opacity=".3"/>
        </svg>

        {/* closed book stack — bottom left */}
        <svg className={`${styles.deco} ${styles.decoBottomLeft}`} viewBox="0 0 140 120" fill="none">
          <rect x="10" y="70" width="120" height="22" rx="4" fill="#c8762a"/>
          <rect x="16" y="48" width="108" height="22" rx="4" fill="#1a6b8a"/>
          <rect x="22" y="28" width="96" height="20" rx="4" fill="#2980b9"/>
          <rect x="28" y="10" width="84" height="18" rx="4" fill="#c0392b"/>
        </svg>

        {/* upright closed book — top centre */}
        <svg className={`${styles.deco} ${styles.decoTop}`} viewBox="0 0 90 130" fill="none">
          <rect x="8" y="0" width="74" height="120" rx="6" fill="#c8762a"/>
          <rect x="8" y="0" width="12" height="120" rx="3" fill="#a05a1a"/>
          <rect x="28" y="20" width="44" height="8" rx="2" fill="#fff" opacity=".2"/>
          <rect x="28" y="36" width="36" height="6" rx="2" fill="#fff" opacity=".15"/>
          <rect x="28" y="50" width="40" height="6" rx="2" fill="#fff" opacity=".15"/>
          <rect x="24" y="72" width="24" height="24" rx="3" fill="#e74c3c" opacity=".7"/>
        </svg>

        {/* teal tall book — top right */}
        <svg className={`${styles.deco} ${styles.decoTopRight}`} viewBox="0 0 60 160" fill="none">
          <rect x="0" y="0" width="56" height="155" rx="5" fill="#1a6b8a"/>
          <rect x="0" y="0" width="10" height="155" rx="3" fill="#145570"/>
          <rect x="18" y="24" width="28" height="6" rx="2" fill="#fff" opacity=".2"/>
          <rect x="18" y="38" width="22" height="5" rx="2" fill="#fff" opacity=".15"/>
        </svg>

        {/* scatter shapes */}
        <div className={`${styles.dot} ${styles.dotA}`}/>
        <div className={`${styles.dot} ${styles.dotB}`}/>
        <div className={`${styles.diamond} ${styles.diamondA}`}/>
        <div className={`${styles.diamond} ${styles.diamondB}`}/>
        <div className={`${styles.diamond} ${styles.diamondC}`}/>
        <div className={`${styles.squiggle} ${styles.squiggleA}`}/>
        <div className={`${styles.squiggle} ${styles.squiggleB}`}/>
      </div>

      {/* ── Payment modal ── */}
      <div className={styles.modal}>
        <div className={styles.modalHeader}>
          <span className={styles.modalTitle}>Complete Payment</span>
          <span className={styles.payableAmount}>Payable Amount: ₹{amount}</span>
        </div>

        {/* Tab switcher */}
        <div className={styles.tabs}>
          {tabs.map(t => (
            <button
              key={t.id}
              className={`${styles.tab} ${tab === t.id ? styles.tabActive : ''}`}
              onClick={() => { setTab(t.id); setError(''); }}
            >
              <span>{t.icon}</span>
              <span>{t.label}</span>
            </button>
          ))}
        </div>

        {/* Form body */}
        <div className={styles.formBody}>

          {/* Credit / Debit card fields */}
          {(tab === 'credit' || tab === 'debit') && (
            <>
              <div className={styles.formRow}>
                <div className={styles.field}>
                  <label className={styles.label}>Card Number</label>
                  <input
                    className={styles.input}
                    placeholder="XXXX-XXXX-XXXX-XXXX"
                    value={cardNumber}
                    onChange={e => setCardNumber(formatCard(e.target.value))}
                    maxLength={19}
                  />
                </div>
                <div className={styles.field}>
                  <label className={styles.label}>Name on Card</label>
                  <input
                    className={styles.input}
                    placeholder="Name"
                    value={nameOnCard}
                    onChange={e => setNameOnCard(e.target.value)}
                  />
                </div>
              </div>
              <div className={styles.formRow}>
                <div className={styles.field}>
                  <label className={styles.label}>CVV</label>
                  <input
                    className={styles.input}
                    placeholder="000"
                    value={cvv}
                    onChange={e => setCvv(e.target.value.replace(/\D/g, '').slice(0, 4))}
                    maxLength={4}
                    type="password"
                  />
                </div>
                <div className={styles.field}>
                  <label className={styles.label}>Date of Expiry</label>
                  <input
                    className={styles.input}
                    placeholder="MM/YY"
                    value={expiry}
                    onChange={e => setExpiry(formatExpiry(e.target.value))}
                    maxLength={5}
                  />
                </div>
              </div>
            </>
          )}

          {/* UPI */}
          {tab === 'upi' && (
            <div className={styles.field}>
              <label className={styles.label}>UPI ID</label>
              <input
                className={styles.input}
                placeholder="yourname@upi"
                value={upiId}
                onChange={e => setUpiId(e.target.value)}
              />
              <p className={styles.hint}>e.g. mobilenumber@upi · name@okaxis · name@paytm</p>
            </div>
          )}

          {/* Wallet */}
          {tab === 'wallet' && (
            <div className={styles.field}>
              <label className={styles.label}>Select Wallet</label>
              <select className={styles.input} value={wallet} onChange={e => setWallet(e.target.value)}>
                {['Paytm', 'PhonePe', 'Amazon Pay', 'Mobikwik', 'Freecharge'].map(w => (
                  <option key={w}>{w}</option>
                ))}
              </select>
              <p className={styles.hint}>You will be redirected to {wallet} to complete payment.</p>
            </div>
          )}

          {error && <p className={styles.error}>{error}</p>}

          <button
            className={`${styles.payBtn} ${processing ? styles.payBtnProcessing : ''}`}
            onClick={handlePay}
            disabled={processing}
          >
            {processing ? (
              <>
                <span className={styles.spinner}/>
                Processing…
              </>
            ) : (
              <>Pay Now <span className={styles.payIcon}>💳</span></>
            )}
          </button>

          <p className={styles.secureNote}>🔒 Secure 128-bit SSL encrypted payment</p>
        </div>
      </div>
    </div>
  );
};

export default PaymentPage;
