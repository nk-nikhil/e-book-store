import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useCart } from '../../context/CartContext';
import styles from './CheckoutPage.module.css';

const TAX_RATE = 0.02;         // 2%

interface AddressForm {
  useSaved: boolean;
  firstName: string;
  lastName: string;
  address1: string;
  address2: string;
  email: string;
  city: string;
  pin: string;
  phone: string;
  state: string;
  country: string;
}

const INDIAN_STATES = [
  'Andhra Pradesh', 'Assam', 'Bihar', 'Chhattisgarh', 'Delhi', 'Goa',
  'Gujarat', 'Haryana', 'Himachal Pradesh', 'Jharkhand', 'Karnataka',
  'Kerala', 'Madhya Pradesh', 'Maharashtra', 'Odisha', 'Punjab',
  'Rajasthan', 'Tamil Nadu', 'Telangana', 'Uttar Pradesh', 'West Bengal',
];

const CheckoutPage: React.FC = () => {
  const navigate = useNavigate();
  const { items, removeFromCart, updateQuantity } = useCart();

  // Address state
  const [form, setForm] = useState<AddressForm>({
    useSaved: false,
    firstName: '', lastName: '',
    address1: '', address2: '',
    email: '', city: '', pin: '',
    phone: '', state: '', country: 'India',
  });

  // Coupon state
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<string | null>(null);
  const [couponError, setCouponError] = useState('');
  const [couponDiscount, setCouponDiscount] = useState(0);

  // Payment method
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'upi' | 'wallet' | 'gift'>('card');

  // Validation error
  const [formError, setFormError] = useState('');

  // ─── Derived totals ───────────────────────────────────────────
  const subtotal = items.reduce((s, i) => s + i.book.price * i.quantity, 0);
  const tax = Math.round(subtotal * TAX_RATE);
  const delivery = subtotal > 300 ? 0 : 49;
  const discount = couponDiscount;
  const total = subtotal + tax + delivery - discount;

  // ─── Handlers ────────────────────────────────────────────────
  const handleFieldChange = (field: keyof AddressForm, value: string | boolean) => {
    setForm(prev => ({ ...prev, [field]: value }));
  };

  const handleApplyCoupon = () => {
    const code = couponCode.trim().toUpperCase();
    if (code === 'SAVE50') { setAppliedCoupon(code); setCouponDiscount(50); setCouponError(''); }
    else if (code === 'BOOKFEST') { setAppliedCoupon(code); setCouponDiscount(100); setCouponError(''); }
    else if (code === 'NEWUSER') { setAppliedCoupon(code); setCouponDiscount(Math.round(subtotal * 0.10)); setCouponError(''); }
    else { setCouponError('Invalid coupon code.'); setAppliedCoupon(null); setCouponDiscount(0); }
  };

  const handleRemoveCoupon = () => {
    setAppliedCoupon(null); setCouponCode(''); setCouponDiscount(0); setCouponError('');
  };

  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.firstName || !form.lastName || !form.address1 || !form.email || !form.city || !form.pin || !form.phone || !form.state) {
      setFormError('Please fill in all required fields before placing your order.');
      return;
    }
    setFormError('');
    // Navigate to payment page, passing total amount and purchased items via state
    navigate(`/payment?amount=${total}`, { state: { purchased: items.map(i => i.book) } });
  };

  // ─── Empty cart guard ─────────────────────────────────────────
  if (items.length === 0) {
    return (
      <main className={styles.page}>
        <div className={styles.emptyCart}>
          <span className={styles.emptyIcon}>🛒</span>
          <h2>Your cart is empty</h2>
          <p>Add some books to proceed to checkout.</p>
          <button className={styles.primaryBtn} onClick={() => navigate('/catalogue')}>Browse Catalogue</button>
        </div>
      </main>
    );
  }

  return (
    <main className={styles.page}>
      {/* Breadcrumb */}
      <nav className={styles.breadcrumb}>
        <Link to="/">Home</Link>
        <span>/</span>
        <span>Non-Fiction</span>
        <span>/</span>
        <span>Self Help</span>
        <span>/</span>
        <span>Joy of Minimalism</span>
        <span>/</span>
        <span className={styles.breadActive}>Checkout</span>
      </nav>

      <h1 className={styles.pageTitle}>Shopping Cart</h1>

      {/* ── Cart Items ── */}
      <div className={styles.cartItems}>
        {items.map(item => (
          <div key={item.book.id} className={styles.cartItem}>
            {/* Cover */}
            <div
              className={styles.itemCover}
              style={{ backgroundColor: item.book.coverColor }}
              onClick={() => navigate(`/book/${item.book.id}`)}
            >
              <span className={styles.itemCoverTitle} style={{ color: item.book.coverTextColor ?? '#fff' }}>
                {item.book.title}
              </span>
              <span className={styles.itemCoverAuthor} style={{ color: item.book.coverTextColor ?? '#fff' }}>
                {item.book.author}
              </span>
            </div>

            {/* Info */}
            <div className={styles.itemInfo}>
              <p className={styles.itemTitle}>{item.book.title}</p>
              <p className={styles.itemAuthor}>
                by <span className={styles.authorLink}>{item.book.author}</span>
              </p>
              <p className={styles.itemDesc}>{item.book.description?.slice(0, 80)}…</p>
              <p className={styles.itemMeta}>Paperback</p>
              <p className={styles.itemDelivery}>
                <Link to={`/book/${item.book.id}`} className={styles.seeMore}>See more</Link>
                {item.book.deliveryDate && ` · Delivery by ${item.book.deliveryDate}`}
              </p>
              <span className={styles.itemPrice}>₹{item.book.price}</span>
            </div>

            {/* Quantity control */}
            <div className={styles.qtyControl}>
              <button
                className={styles.qtyBtn}
                onClick={() => updateQuantity(item.book.id, item.quantity - 1)}
                disabled={item.quantity <= 1}
                aria-label="Decrease quantity"
              >−</button>
              <span className={styles.qtyValue}>{item.quantity}</span>
              <button
                className={styles.qtyBtn}
                onClick={() => updateQuantity(item.book.id, item.quantity + 1)}
                aria-label="Increase quantity"
              >+</button>
            </div>

            {/* Remove */}
            <button
              className={styles.removeBtn}
              onClick={() => removeFromCart(item.book.id)}
              aria-label={`Remove ${item.book.title}`}
            >✕</button>
          </div>
        ))}
      </div>

      {/* ── Bottom 2-column: Address + Grand Total ── */}
      <div className={styles.bottomLayout}>

        {/* Address Form */}
        <form className={styles.addressSection} onSubmit={handlePlaceOrder} noValidate>
          <h2 className={styles.sectionTitle}>Address</h2>

          <label className={styles.savedLabel}>
            <input
              type="checkbox"
              checked={form.useSaved}
              onChange={e => handleFieldChange('useSaved', e.target.checked)}
            />
            <span>Use Saved Address</span>
          </label>

          <div className={styles.formRow}>
            <div className={styles.formField}>
              <label className={styles.fieldLabel}>First Name *</label>
              <input className={styles.input} placeholder="First Name" value={form.firstName}
                onChange={e => handleFieldChange('firstName', e.target.value)} required />
            </div>
            <div className={styles.formField}>
              <label className={styles.fieldLabel}>Last Name *</label>
              <input className={styles.input} placeholder="Last Name" value={form.lastName}
                onChange={e => handleFieldChange('lastName', e.target.value)} required />
            </div>
            <div className={styles.formField + ' ' + styles.formFieldWide}>
              <label className={styles.fieldLabel}>Address *</label>
              <input className={styles.input} placeholder="Address Line 1" value={form.address1}
                onChange={e => handleFieldChange('address1', e.target.value)} required />
            </div>
          </div>

          <div className={styles.formRow}>
            <div className={styles.formField}>
              <label className={styles.fieldLabel}>e-mail *</label>
              <input className={styles.input} placeholder="e-mail" type="email" value={form.email}
                onChange={e => handleFieldChange('email', e.target.value)} required />
            </div>
            <div className={styles.formField}>
              <label className={styles.fieldLabel}>City *</label>
              <input className={styles.input} placeholder="City" value={form.city}
                onChange={e => handleFieldChange('city', e.target.value)} required />
            </div>
            <div className={styles.formField}>
              <label className={styles.fieldLabel}>Pin *</label>
              <input className={styles.input} placeholder="000000" value={form.pin} maxLength={6}
                onChange={e => handleFieldChange('pin', e.target.value.replace(/\D/g, ''))} required />
            </div>
          </div>

          <div className={styles.formRow}>
            <div className={styles.formField}>
              <label className={styles.fieldLabel}>Phone number *</label>
              <div className={styles.phoneRow}>
                <select className={`${styles.input} ${styles.dialCode}`} aria-label="Dial code">
                  <option>+91</option><option>+1</option><option>+44</option>
                </select>
                <input className={styles.input} placeholder="10-digit Mobile" value={form.phone}
                  onChange={e => handleFieldChange('phone', e.target.value.replace(/\D/g, ''))} maxLength={10} required />
              </div>
            </div>
            <div className={styles.formField}>
              <label className={styles.fieldLabel}>State *</label>
              <select className={styles.input} value={form.state}
                onChange={e => handleFieldChange('state', e.target.value)} required>
                <option value="">Select State</option>
                {INDIAN_STATES.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
            <div className={styles.formField}>
              <label className={styles.fieldLabel}>Country</label>
              <select className={styles.input} value={form.country}
                onChange={e => handleFieldChange('country', e.target.value)}>
                <option>India</option><option>United States</option><option>United Kingdom</option>
              </select>
            </div>
          </div>

          {/* Payment method selector */}
          <h2 className={`${styles.sectionTitle} ${styles.paymentTitle}`}>Payment Method</h2>
          <div className={styles.paymentMethods}>
            {(['card', 'upi', 'wallet', 'gift'] as const).map(method => (
              <label key={method} className={`${styles.paymentOption} ${paymentMethod === method ? styles.paymentActive : ''}`}>
                <input type="radio" name="payment" value={method}
                  checked={paymentMethod === method}
                  onChange={() => setPaymentMethod(method)} />
                <span className={styles.paymentIcon}>
                  {method === 'card' ? '💳' : method === 'upi' ? '📱' : method === 'wallet' ? '👛' : '🎁'}
                </span>
                <span className={styles.paymentLabel}>
                  {method === 'card' ? 'Credit / Debit Card' : method === 'upi' ? 'UPI / Net Banking' : method === 'wallet' ? 'Wallet' : 'Gift Points'}
                </span>
              </label>
            ))}
          </div>

          {formError && <p className={styles.formError}>{formError}</p>}
        </form>

        {/* Grand Total Panel */}
        <aside className={styles.totalPanel}>
          {/* Decorative book graphic */}
          <div className={styles.panelGraphic}>
            <div className={styles.graphicBook} style={{ background: '#f39c12', transform: 'rotate(-8deg)' }} />
            <div className={styles.graphicBook} style={{ background: '#2980b9', transform: 'rotate(4deg)', marginLeft: '-20px' }} />
            <div className={styles.graphicBook} style={{ background: '#c0392b', transform: 'rotate(12deg)', marginLeft: '-24px' }} />
          </div>

          <h2 className={styles.totalHeading}>Grand Total</h2>

          <div className={styles.totalRows}>
            <div className={styles.totalRow}>
              <span>Price ({items.length} item{items.length !== 1 ? 's' : ''})</span>
              <span>₹{subtotal}.00</span>
            </div>
            <div className={styles.totalRow}>
              <span>Tax (2%)</span>
              <span>₹{tax}.00</span>
            </div>
            <div className={styles.totalRow}>
              <span>Delivery Charges</span>
              <span className={delivery === 0 ? styles.freeTag : ''}>
                {delivery === 0 ? 'Free' : `₹${delivery}`}
              </span>
            </div>
          </div>

          <div className={styles.couponRow}>
            {appliedCoupon ? (
              <div className={styles.appliedCoupon}>
                <span>🏷️ <strong>{appliedCoupon}</strong> applied</span>
                <button className={styles.removeCouponBtn} onClick={handleRemoveCoupon}>✕</button>
              </div>
            ) : (
              <>
                <input
                  className={styles.couponInput}
                  placeholder="Apply Coupon"
                  value={couponCode}
                  onChange={e => { setCouponCode(e.target.value); setCouponError(''); }}
                  onKeyDown={e => e.key === 'Enter' && handleApplyCoupon()}
                />
                <button className={styles.applyBtn} onClick={handleApplyCoupon}>Apply</button>
              </>
            )}
          </div>
          {couponError && <p className={styles.couponError}>{couponError}</p>}
          <p className={styles.couponHint}>Try: SAVE50 · BOOKFEST · NEWUSER</p>

          <div className={styles.totalRows}>
            <div className={styles.totalRow}>
              <span>Discount</span>
              <span className={styles.discountVal}>- ₹{discount}.00</span>
            </div>
          </div>

          <div className={styles.grandTotalRow}>
            <span>Total Amount</span>
            <span className={styles.grandAmount}>₹{total}</span>
          </div>

          <button
            className={styles.payNowBtn}
            onClick={handlePlaceOrder}
          >
            Pay Now
            <span className={styles.payIcon}>
              {paymentMethod === 'card' ? '💳' : paymentMethod === 'upi' ? '📱' : paymentMethod === 'wallet' ? '👛' : '🎁'}
            </span>
          </button>

          <p className={styles.secureNote}>🔒 Secure payment · 100% safe checkout</p>
        </aside>
      </div>
    </main>
  );
};

export default CheckoutPage;
