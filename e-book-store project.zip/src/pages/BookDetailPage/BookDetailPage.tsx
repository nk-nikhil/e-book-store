import React, { useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { allBooks } from '../../data/books';
import { useCart } from '../../context/CartContext';
import { Review } from '../../types';
import styles from './BookDetailPage.module.css';

const StarRating: React.FC<{ rating: number; interactive?: boolean; onRate?: (r: number) => void }> = ({
  rating, interactive = false, onRate,
}) => (
  <span className={styles.stars}>
    {[1, 2, 3, 4, 5].map(i => (
      <span
        key={i}
        style={{ color: i <= Math.round(rating) ? '#f39c12' : '#4a5568', cursor: interactive ? 'pointer' : 'default', fontSize: interactive ? 20 : 14 }}
        onClick={() => interactive && onRate?.(i)}
      >★</span>
    ))}
  </span>
);

const BookDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { addToCart, items } = useCart();

  const book = allBooks.find(b => b.id === Number(id));

  const [toast, setToast] = useState<string | null>(null);
  const [wishlisted, setWishlisted] = useState(false);
  const [newReviewRating, setNewReviewRating] = useState(0);
  const [newReviewText, setNewReviewText] = useState('');
  const [reviews, setReviews] = useState<Review[]>(book?.reviews ?? []);

  if (!book) {
    return (
      <main className={styles.page}>
        <p className={styles.notFound}>Book not found. <button onClick={() => navigate('/')}>Go Home</button></p>
      </main>
    );
  }

  const inCart = items.find(i => i.book.id === book.id);
  const relatedBooks = allBooks.filter(b => b.category === book.category && b.id !== book.id).slice(0, 4);

  const handleAddToCart = () => {
    addToCart(book);
    setToast(`"${book.title}" added to cart!`);
    setTimeout(() => setToast(null), 2500);
  };

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReviewText.trim() || newReviewRating === 0) return;
    const review: Review = {
      id: Date.now(),
      reviewer: 'You',
      rating: newReviewRating,
      comment: newReviewText.trim(),
      date: new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }),
    };
    setReviews(prev => [review, ...prev]);
    setNewReviewText('');
    setNewReviewRating(0);
  };

  return (
    <main className={styles.page}>
      {toast && <div className={styles.toast}>{toast}</div>}

      {/* Breadcrumb */}
      <nav className={styles.breadcrumb}>
        <Link to="/">Home</Link>
        <span>/</span>
        <Link to="/catalogue">Book Catalog</Link>
        <span>/</span>
        <span>{book.category}</span>
        <span>/</span>
        <span>{book.title}</span>
      </nav>

      <div className={styles.layout}>
        {/* ── LEFT: book detail ── */}
        <div className={styles.main}>
          <div className={styles.hero}>
            {/* Cover */}
            <div className={styles.coverWrap} style={{ backgroundColor: book.coverColor }}>
              <span className={styles.coverTitle} style={{ color: book.coverTextColor ?? '#fff' }}>
                {book.title}
              </span>
              <span className={styles.coverAuthor} style={{ color: book.coverTextColor ?? '#fff' }}>
                {book.author}
              </span>
            </div>

            {/* Detail panel */}
            <div className={styles.detail}>
              <h1 className={styles.bookTitle}>{book.title}</h1>
              <p className={styles.bookAuthor}>
                by <span className={styles.authorLink}>{book.author}</span>
              </p>
              {book.publisher && (
                <p className={styles.meta}>Published by <span>{book.publisher}</span></p>
              )}
              {book.rating && (
                <div className={styles.ratingRow}>
                  <StarRating rating={book.rating} />
                  <span className={styles.ratingNum}>{book.rating.toFixed(1)}</span>
                  {book.soldCount && <span className={styles.soldCount}>· {book.soldCount} Sold</span>}
                </div>
              )}

              <p className={styles.description}>{book.description}</p>

              <div className={styles.metaGrid}>
                <span className={styles.metaLabel}>Format:</span><span>Paperback</span>
                {book.language && <><span className={styles.metaLabel}>Language:</span><span>{book.language}</span></>}
                {book.pages && <><span className={styles.metaLabel}>Pages:</span><span>{book.pages}</span></>}
              </div>

              <div className={styles.priceRow}>
                <span className={styles.price}>₹{book.price}</span>
                {book.originalPrice && (
                  <span className={styles.originalPrice}>₹{book.originalPrice}</span>
                )}
              </div>

              {book.deliveryDate && (
                <p className={styles.delivery}>📦 Delivery by <strong>{book.deliveryDate}</strong></p>
              )}

              <div className={styles.actionRow}>
                <button
                  className={`${styles.cartBtn} ${inCart ? styles.cartBtnActive : ''}`}
                  onClick={handleAddToCart}
                >
                  {inCart ? `In Cart (${inCart.quantity})` : 'Add to Cart'}
                </button>
                <button
                  className={`${styles.wishBtn} ${wishlisted ? styles.wishBtnActive : ''}`}
                  onClick={() => setWishlisted(w => !w)}
                >
                  {wishlisted ? '❤️ Wishlisted' : '🤍 Add to Wishlist'}
                </button>
              </div>

              <div className={styles.statsRow}>
                <div className={styles.stat}>
                  <span className={styles.statLabel}>Language</span>
                  <span>{book.language ?? 'English'}</span>
                </div>
                <div className={styles.stat}>
                  <span className={styles.statLabel}>Ratings</span>
                  <span>{book.rating?.toFixed(1) ?? '—'}</span>
                </div>
                <div className={styles.stat}>
                  <span className={styles.statLabel}>Sales</span>
                  <span>{book.soldCount ? `${book.soldCount} copies sold` : '—'}</span>
                </div>
              </div>
            </div>
          </div>

          {/* About the Writer */}
          {book.authorDetail && (
            <section className={styles.authorSection}>
              <h2 className={styles.sectionHeading}>About the writer</h2>
              <div className={styles.authorCard}>
                <div className={styles.avatar} style={{ backgroundColor: book.authorDetail.avatarColor }}>
                  {book.authorDetail.name.charAt(0)}
                </div>
                <div>
                  <p className={styles.authorName}>{book.authorDetail.name}</p>
                  <p className={styles.authorBio}>{book.authorDetail.bio}</p>
                </div>
              </div>
            </section>
          )}

          {/* Reviews */}
          <section className={styles.reviewsSection}>
            <h2 className={styles.sectionHeading}>Reviews</h2>

            {/* Submit review */}
            <form className={styles.reviewForm} onSubmit={handleSubmitReview}>
              <p className={styles.reviewFormLabel}>Leave Your Review</p>
              <StarRating rating={newReviewRating} interactive onRate={setNewReviewRating} />
              <textarea
                className={styles.reviewInput}
                placeholder="Write your review here..."
                value={newReviewText}
                onChange={e => setNewReviewText(e.target.value)}
                rows={3}
              />
              <div className={styles.reviewFormFooter}>
                <button
                  type="submit"
                  className={styles.submitBtn}
                  disabled={!newReviewText.trim() || newReviewRating === 0}
                >
                  Submit →
                </button>
              </div>
            </form>

            {/* Existing reviews */}
            <div className={styles.reviewList}>
              {reviews.length === 0 && (
                <p className={styles.noReviews}>No reviews yet. Be the first to review!</p>
              )}
              {reviews.map(r => (
                <div key={r.id} className={styles.reviewCard}>
                  <div className={styles.reviewHeader}>
                    <div className={styles.reviewAvatar}>{r.reviewer.charAt(0)}</div>
                    <div>
                      <p className={styles.reviewerName}>{r.reviewer}</p>
                      <p className={styles.reviewDate}>{r.date}</p>
                    </div>
                    <StarRating rating={r.rating} />
                  </div>
                  <p className={styles.reviewComment}>{r.comment}</p>
                </div>
              ))}
            </div>
          </section>
        </div>

        {/* ── RIGHT: Related Reads ── */}
        <aside className={styles.sidebar}>
          <h3 className={styles.sidebarHeading}>Related Reads</h3>
          <div className={styles.relatedList}>
            {relatedBooks.length === 0 && (
              <p className={styles.noRelated}>No related books found.</p>
            )}
            {relatedBooks.map(rb => (
              <div
                key={rb.id}
                className={styles.relatedCard}
                onClick={() => navigate(`/book/${rb.id}`)}
              >
                <div className={styles.relatedCover} style={{ backgroundColor: rb.coverColor }}>
                  <span style={{ color: rb.coverTextColor ?? '#fff', fontSize: 9, fontWeight: 700, textAlign: 'center', padding: '4px' }}>
                    {rb.title}
                  </span>
                </div>
                <div className={styles.relatedInfo}>
                  <p className={styles.relatedTitle}>{rb.title}</p>
                  <p className={styles.relatedAuthor}>By <span>{rb.author}</span></p>
                  <p className={styles.relatedDesc}>{rb.description?.slice(0, 60)}...</p>
                  <p className={styles.relatedMeta}>Paperback</p>
                  <p className={styles.relatedPrice}>₹{rb.price}</p>
                  {rb.originalPrice && (
                    <p className={styles.relatedOriginal}>₹{rb.originalPrice}</p>
                  )}
                  {rb.deliveryDate && (
                    <p className={styles.relatedDelivery}>Delivery by {rb.deliveryDate}</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </aside>
      </div>
    </main>
  );
};

export default BookDetailPage;
