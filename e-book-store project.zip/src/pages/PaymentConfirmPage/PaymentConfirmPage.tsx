import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import styles from './PaymentConfirmPage.module.css';

interface PurchasedBook {
  id: number;
  title: string;
  author: string;
  price: number;
  originalPrice?: number;
  coverColor: string;
  coverTextColor?: string;
  deliveryDate?: string;
  description?: string;
}

const PaymentConfirmPage: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();

  // Books passed via navigation state (set from PaymentPage after clearCart)
  const purchased: PurchasedBook[] = (location.state as { purchased?: PurchasedBook[] })?.purchased ?? [];

  return (
    <div className={styles.scene}>
      {/* Shared illustrated background */}
      <div className={styles.bg}>
        <svg className={`${styles.deco} ${styles.decoBottomRight}`} viewBox="0 0 260 180" fill="none">
          <path d="M10 160 Q130 100 250 160 L250 20 Q130 80 10 20Z" fill="#c8762a" opacity=".85"/>
          <path d="M130 100 L130 160" stroke="#a05a1a" strokeWidth="3"/>
          <rect x="30" y="40" width="80" height="8" rx="2" fill="#a05a1a" opacity=".4"/>
          <rect x="30" y="56" width="60" height="6" rx="2" fill="#a05a1a" opacity=".3"/>
          <rect x="150" y="40" width="80" height="8" rx="2" fill="#a05a1a" opacity=".4"/>
          <rect x="150" y="56" width="60" height="6" rx="2" fill="#a05a1a" opacity=".3"/>
        </svg>
        <svg className={`${styles.deco} ${styles.decoBottomLeft}`} viewBox="0 0 140 120" fill="none">
          <rect x="10" y="70" width="120" height="22" rx="4" fill="#c8762a"/>
          <rect x="16" y="48" width="108" height="22" rx="4" fill="#1a6b8a"/>
          <rect x="22" y="28" width="96" height="20" rx="4" fill="#2980b9"/>
          <rect x="28" y="10" width="84" height="18" rx="4" fill="#c0392b"/>
        </svg>
        <svg className={`${styles.deco} ${styles.decoTop}`} viewBox="0 0 90 130" fill="none">
          <rect x="8" y="0" width="74" height="120" rx="6" fill="#c8762a"/>
          <rect x="8" y="0" width="12" height="120" rx="3" fill="#a05a1a"/>
          <rect x="28" y="20" width="44" height="8" rx="2" fill="#fff" opacity=".2"/>
          <rect x="24" y="72" width="24" height="24" rx="3" fill="#e74c3c" opacity=".7"/>
        </svg>
        <svg className={`${styles.deco} ${styles.decoTopRight}`} viewBox="0 0 60 160" fill="none">
          <rect x="0" y="0" width="56" height="155" rx="5" fill="#1a6b8a"/>
          <rect x="0" y="0" width="10" height="155" rx="3" fill="#145570"/>
          <rect x="18" y="24" width="28" height="6" rx="2" fill="#fff" opacity=".2"/>
        </svg>
        <div className={`${styles.dot} ${styles.dotA}`}/>
        <div className={`${styles.dot} ${styles.dotB}`}/>
        <div className={`${styles.diamond} ${styles.diamondA}`}/>
        <div className={`${styles.diamond} ${styles.diamondB}`}/>
        <div className={`${styles.squiggle} ${styles.squiggleA}`}/>
        <div className={`${styles.squiggle} ${styles.squiggleB}`}/>
      </div>

      {/* ── Confirmation modal ── */}
      <div className={styles.modal}>
        {/* Green tick */}
        <div className={styles.tickWrap}>
          <svg className={styles.tickCircle} viewBox="0 0 52 52">
            <circle className={styles.tickRing} cx="26" cy="26" r="24" fill="none" stroke="#27ae60" strokeWidth="3"/>
            <polyline className={styles.tickMark} points="14,27 22,35 38,17" fill="none" stroke="#27ae60" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>

        <p className={styles.message}>
          Your purchase of the<br/>
          following reads is successful.
        </p>

        {/* Purchased book cards */}
        {purchased.length > 0 ? (
          <div className={styles.bookList}>
            {purchased.map(book => (
              <div key={book.id} className={styles.bookCard} onClick={() => navigate(`/book/${book.id}`)}>
                <div className={styles.bookCover} style={{ backgroundColor: book.coverColor }}>
                  <span className={styles.coverTitle} style={{ color: book.coverTextColor ?? '#fff' }}>
                    {book.title}
                  </span>
                  <span className={styles.coverAuthor} style={{ color: book.coverTextColor ?? '#fff' }}>
                    {book.author}
                  </span>
                </div>
                <div className={styles.bookInfo}>
                  <p className={styles.bookTitle}>{book.title}</p>
                  <p className={styles.bookAuthor}>By <span>{book.author}</span></p>
                  <p className={styles.bookDesc}>{book.description?.slice(0, 55)}…</p>
                  <p className={styles.bookMeta}>Paperback</p>
                  {/* Link placeholder */}
                  <p className={styles.seeMore}>Non-fiction · Self Help</p>
                  <div className={styles.priceRow}>
                    <span className={styles.price}>₹{book.price}</span>
                    {book.originalPrice && (
                      <span className={styles.original}>₹{book.originalPrice}</span>
                    )}
                  </div>
                  {book.deliveryDate && (
                    <p className={styles.delivery}>Delivery by {book.deliveryDate}</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className={styles.noBooksMsg}>Your order has been placed successfully.</p>
        )}

        <button className={styles.continueBtn} onClick={() => navigate('/')}>
          Continue your Shopping
          <span className={styles.arrowIcon}>→</span>
        </button>
      </div>
    </div>
  );
};

export default PaymentConfirmPage;
