import React, { useState, useCallback } from 'react';
import BookSection from '../../components/BookSection/BookSection';
import { recommendedBooks, bestsellerBooks, newLaunchBooks } from '../../data/books';
import { Book } from '../../types';
import styles from './HomePage.module.css';

const HomePage: React.FC = () => {
  const [toast, setToast] = useState<string | null>(null);

  const handleAddToCart = useCallback((book: Book) => {
    setToast(`"${book.title}" added to cart!`);
    setTimeout(() => setToast(null), 2500);
  }, []);

  return (
    <main className={styles.main}>
      {toast && <div className={styles.toast}>{toast}</div>}

      <BookSection
        title="Recommended for You"
        books={recommendedBooks}
        onAddToCart={handleAddToCart}
      />
      <BookSection
        title="Bestsellers this Month"
        books={bestsellerBooks}
        onAddToCart={handleAddToCart}
      />
      <BookSection
        title="New Launches"
        books={newLaunchBooks}
        onAddToCart={handleAddToCart}
      />
    </main>
  );
};

export default HomePage;
